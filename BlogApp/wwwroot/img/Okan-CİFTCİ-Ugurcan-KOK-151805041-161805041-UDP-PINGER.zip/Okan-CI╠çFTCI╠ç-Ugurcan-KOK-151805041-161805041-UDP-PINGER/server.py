
import random
import sys
from socket import *

host = "127.0.0.1"
port = 12000

serverSocket = socket(AF_INET,SOCK_DGRAM)
serverSocket.bind(("127.0.0.1",12000))

print("Server is ready to serve...")

while True:
  rand = random.randint(0,10)
  message,addr = serverSocket.recvfrom(1024)
  message = message.decode("utf-8")
  print("The message was sent from client -> "+message)
  message = message.upper()
  if rand < 4 :
    print("Nothing send to the client")
    print("")
    continue
  serverSocket.sendto(message.encode("utf-8"),addr)
  print("Message was sent as uppercase to client")
  print("")  
