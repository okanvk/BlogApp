
import sys

from socket import *
import  time

host="159.65.86.119"
port=12000

clientSocket = socket(AF_INET,SOCK_DGRAM)
clientSocket.settimeout(1)

server = (host,port)

for i in range(100):
  sendTime = time.time()
  message = "Ping " + str(i+1) + " " + str(time.strftime("%a %b %Y %H: %M: %S"))
  clientSocket.sendto(message.encode("utf-8"),server)

  try:
    data,addr = clientSocket.recvfrom(1024)
    recdTime = time.time()
    rtt = recdTime - sendTime
    print("Reply from",str(addr),data.decode("utf-8"))
    print("Round Trip Time (RTT) :",rtt)
    print("")
  except timeout:
    print("Request timed out for ping",str(i+1)+ " Okan Ciftci - Ugurcan kök")  